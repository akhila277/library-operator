package v1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

type BookSpec struct {
	Title  string `json:"title,omitempty"`
	Author string `json:"author,omitempty"`
}

type BookStatus struct {
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status

type Book struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   BookSpec   `json:"spec,omitempty"`
	Status BookStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

type BookList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []Book `json:"items"`
}

func init() {
	SchemeBuilder.Register(&Book{}, &BookList{})
}
