package main

import (
	"database/sql"
	"log"
	"os"

	_ "github.com/lib/pq" // PostgreSQL driver
	"sigs.k8s.io/controller-runtime/pkg/client/config"
	"sigs.k8s.io/controller-runtime/pkg/healthz"
	"sigs.k8s.io/controller-runtime/pkg/log/zap"
	"sigs.k8s.io/controller-runtime/pkg/manager"

	// Assuming you have a scheme setup and a BookReconciler in your project
	"github.com/example/library-operator/controllers"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/client-go/kubernetes/scheme"
)

var (
	setupLog             = log.New(os.Stdout, "setup: ", log.Lshortfile)
	metricsAddr          = ":8080"
	probeAddr            = ":8081"
	enableLeaderElection = true
)

func main() {
	ctrl.SetLogger(zap.New(zap.UseDevMode(true)))

	// Connect to the PostgreSQL database
	db, err := sql.Open("postgres", "host=myhost port=myport user=myuser password=mypassword dbname=mydbname sslmode=disable")
	if err != nil {
		setupLog.Println("unable to connect to database", err)
		os.Exit(1)
	}
	defer db.Close()

	// Create a new scheme and add all necessary schemes to it
	sch := runtime.NewScheme()
	scheme.AddToScheme(sch)

	// Set up the manager
	mgr, err := manager.New(config.GetConfigOrDie(), manager.Options{
		Scheme:                 sch,
		MetricsBindAddress:     metricsAddr,
		Port:                   9443,
		HealthProbeBindAddress: probeAddr,
		LeaderElection:         enableLeaderElection,
		LeaderElectionID:       "0220e77b.example.com",
	})
	if err != nil {
		setupLog.Println("unable to start manager", err)
		os.Exit(1)
	}

	// Set up the controller with the manager
	if err = controllers.NewBookReconciler(
		mgr.GetClient(),
		mgr.GetScheme(),
		db, // Pass the SQL database connection to the reconciler
	).SetupWithManager(mgr); err != nil {
		setupLog.Println("unable to create controller", "controller", "Book", err)
		os.Exit(1)
	}

	// Add health and readiness checks
	if err := mgr.AddHealthzCheck("healthz", healthz.Ping); err != nil {
		setupLog.Println("unable to set up health check", err)
		os.Exit(1)
	}
	if err := mgr.AddReadyzCheck("readyz", healthz.Ping); err != nil {
		setupLog.Println("unable to set up ready check", err)
		os.Exit(1)
	}

	// Start the manager
	setupLog.Println("starting manager")
	if err := mgr.Start(ctrl.SetupSignalHandler()); err != nil {
		setupLog.Println("problem running manager", err)
		os.Exit(1)
	}
}
